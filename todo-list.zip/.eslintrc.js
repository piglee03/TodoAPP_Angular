export default {
    "extends": "standard"

};