export class Todo {
    id:number;
    text: String;
    isDone: boolean;
}