export class Todo {
    id: Number;
    text: String;
    date: String;
    isDone: Boolean;
}
