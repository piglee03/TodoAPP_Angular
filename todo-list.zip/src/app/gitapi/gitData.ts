export interface GitData {
    login: string;
    name: string;
    location: string;
    url: string;
}
