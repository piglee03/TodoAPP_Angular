import { Component, OnDestroy } from '@angular/core';
import { Todo } from '../todo';
import { NgRedux } from '../../../node_modules/@angular-redux/store';
import { IAppState } from '../../store';
import { TodoActions } from '../app.actions';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})

export class ListComponent implements OnDestroy {
  list: Todo[];
  subscription;

  constructor(
    private ngRedux: NgRedux<IAppState>,
    private actions: TodoActions) {
      this.subscription = ngRedux.select<Todo[]>('todoList')
      .subscribe(newList => this.list = newList);
    }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  delItem(id: number): void {
    this.ngRedux.dispatch(this.actions.delete(id));
  }

  flagReverse(id: number): void {
    this.ngRedux.dispatch(this.actions.reverse(id));
  }
}
