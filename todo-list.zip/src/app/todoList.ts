import {Todo} from './todo';

export var LIST: Todo[] = [
]