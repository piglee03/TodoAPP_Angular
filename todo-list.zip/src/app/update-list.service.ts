import { Injectable } from '@angular/core';
import {Observable, of} from 'rxjs';
import {Todo} from './todo';
import {LIST} from './todoList';
@Injectable({
  providedIn: 'root'
})
export class UpdateListService {
  constructor() { }
  getList(): Observable<Todo[]> {
    return of(LIST);
  }
  addItem(id:number, text: string): void {
    LIST.push({id:id, text:text, isDone:false});
  }
  delItem(id:number):void {
    var index = LIST.map(item => item.id).indexOf(id);
    LIST.splice(index, 1);
  }
  doneReverse(id:number):void {
    var index = LIST.map(item => item.id).indexOf(id);
    LIST[index].isDone = !LIST[index].isDone;
  }
}
